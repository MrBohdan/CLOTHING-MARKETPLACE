﻿// BUYME_CLOTHING_MARKETPLACE.cpp : Defines the entry point for the console application.
//

#include <cstdlib>
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstdio>
#include <io.h>
#include <fcntl.h>


using namespace std;



struct Clothes
{
	int item_id=8;
	string name_of_clothing;
	string type_of_clothing;
	string description;
	int quantity;
	string colour;
	string size;
	float price;
	Clothes * next;
	Clothes * back;
}*new_item, *head, *tail, *list;

struct Fixed_Clothes
{
	int fixed_item_id;
	string fixed_name_of_clothing;
	string fixed_type_of_clothing;
	string fixed_description;
	int fixed_quantity;
	string fixed_colour;
	string fixed_size;
	float fixed_price;
	Fixed_Clothes * next_f;
	Fixed_Clothes * back_f;
}*fixed_item,*previous, *head_f, *tail_f, *list_f;

struct Selected_Clothes
{
	int selected_item_id;
	string selected_name_of_clothing;
	string selected_type_of_clothing;
	string selected_description;
	int selected_quantity;
	string selected_colour;
	string selected_size;
	float selected_price;
	Selected_Clothes * next_seld;
	Selected_Clothes * back_seld;
}*selected_item, *head_seld, *tail_seld, *list_seld, *previous_seld;

struct Checkout
{
	int checkout_item_id;
	string  checkout_name_of_clothing;
	string  checkout_colour;
	string  buyername;
	string  address;
	int phone_nember;
	string  checkout_size;
	float  checkout_price;
	Checkout * next_check;
	Checkout * back_check;
}*selected_check, *head_check, *tail_check, *list_check, *previous_check;

float new_price;
float old_price;
float total;
float balance;


int palce_and_order_menu();
int view_orders_menu();
void add_New_item(string item_id, string name_of_clothing,
string type_of_clothing, string description, string quantity, string colour, string size, string price);
void Add_fixed_item(string fixed_item_id, string fixed_name_of_clothing,
	string fixed_type_of_clothing, string fixed_description, string fixed_quantity, 
	string fixed_colour, string fixed_size, string fixed_price);
void List_of_items();
int add_clothing(string type_of_clothing);
void fixed_list();
void search_in_added(string type_of_clothing);
void search_in_fixed(string input);
void dispaly_added();
void delete_node_from_selected(int remValue);
void move_by_clothes();
void move_by_newclothes();
void select_to_order();
void select_to_order_non_fixed();
void Add_to_selected(int id, int quantity, float price, string name_of_clothing,
	string type_of_clothing, string description, string colour, string size);
void checkout();
void checkout_step2();
void Add_to_orders(int remValue,float price, string name_of_clothing, string colour, string size, string buyer_name,string address,int phone_number);
void deleteAtEnd();
void deleteAtBeginning();
void view_orders();
void move_between_orders();

int main()
{
	int select;
	cout << "------Welcome to Buy me clothing market place------\n";
	cout << ">[1] Place an order.\n>[2] View orders.\n>[3] Exit\n";
	cout << ">Select option>>>: ";
	// to call this function just once 
	static bool initialized;
	if (!initialized) {
		initialized = true;
		fixed_list();
	}
	cin >> select;
	switch (select)
	{
	case 1:palce_and_order_menu();break;
	case 2:view_orders_menu();break;
	case 3:exit(0); break;
	default:main();break;
	}
	system("PAUSE");
	return 0;
}

int palce_and_order_menu() {
	string element, input;
	int select;
	cout << ">[1]Add clothing\n>[2]View a list of clothes for sale.\n>[3]Search for a type of clothing.\n>[4]Move back and forth between the clothes that are for sale. \n>[5]Select clothes to order.\n>[6]Checkout order.\n>[7]Back to menu.\n";
	cout << ">Select option---->";
	cin >> select;
	switch (select)
	{
	case 1:add_clothing(element);break;
	case 2:List_of_items();dispaly_added(); system("PAUSE"); palce_and_order_menu(); break;
	case 3:cout << ">>>>>>>Search modul<<<<<<<\n";cout << "Enter type of clothing (Jeans, Shirt, T-shirts, Jackets, Backpack)\n";
		cout << "Enter: ";cin >> input;
		search_in_fixed(input);
		search_in_added(input);
		system("PAUSE");palce_and_order_menu();break;
	case 4:move_by_clothes(); move_by_newclothes(); break;
	case 5:select_to_order(); select_to_order_non_fixed(); break;
	case 6:checkout(); break;
	case 7:main(); break;
	}
	system("PAUSE");
	return 0;
}
int view_orders_menu() {
	int select, input;
	cout << ">[1]View orders.\n>[2]Move back and forth between orders.\n>[3]Modify an order. \n>[4]Delete an order.\n>[5]Back to main menu.\nSelect: ";
	cin >> select;
	switch (select)
	{
	case 1:view_orders(); break;
	case 2:move_between_orders(); break;
	case 4:cout << "Enter your order ID to delete\n\nType ID :";
		cin >> input;
		delete_node_from_selected(input); break;
	case 5:main(); break;
	default:break;
	}
	system("PAUSE");
	return 0;
}
int add_clothing(string type_of_clothing) {
	int select, gen_id=7;
	string name_of_clothing, description, colour, item_id, quantity, size, price;
	list = head;
	while (list != NULL)
	{
		gen_id = list->item_id;
		list = list->next;
		
	}
	if (gen_id>=7) {
		gen_id++;
	}
	cout << "Item ID - \t:" << gen_id<<"\n";
	//convert integer to string
	std::string x = std::to_string(gen_id);
	cout << "Enter Name of item\t: ";
	cin >> name_of_clothing;
	cout << "Selct Type:\n>[1]Jeans\n>[2]Shirt\n>[3]T-shirts\n>[4]Jackets\n>[5]Backpack\nSelect: " ;
	cin >> select;
	string jeans = "Jeans", jackets = "Jackets", shirt = "Shirt", t_shirt = "T-shirts",backpack = "Backpack";
		switch (select)
		{
		case 1:type_of_clothing = jeans; break;
		case 2:type_of_clothing = jackets; break;
		case 3:type_of_clothing = shirt; break;
		case 4:type_of_clothing = t_shirt; break;
		case 5:type_of_clothing = backpack; break;
		default:system("PAUSE");main();break;
		}
	cout << "Enter description\t: ";
	cin >> description;
	cout << "Enter quantity\t: ";
	cin >> quantity;
	cout << "Enter colour\t: ";
	cin >> colour;
	cout << "Enter size\t: ";
	cin >> size;
	cout << "Enter price: ";
	cin >> price;
	string new_item[8] = { x, name_of_clothing, type_of_clothing, description, quantity, colour ,size ,price };
	add_New_item(new_item[0], new_item[1], new_item[2], new_item[3], new_item[4], new_item[5], new_item[6], new_item[7]);
	system("PAUSE");
	main();
	return 0;
}
void  add_New_item(string item_id, string name_of_clothing, string type_of_clothing,
	string description, string quantity, string colour, string size, string price)
{
	new_item = new Clothes();
	new_item->item_id = stoi(item_id);
	new_item->name_of_clothing = name_of_clothing;
	new_item->type_of_clothing = type_of_clothing;
	new_item->description = description;
	new_item->quantity = stoi(quantity);
	new_item->colour = colour;
	new_item->size = size;
	new_item->price = stof(price);
	new_item->back = NULL;
	new_item->next = NULL;
	if (head == NULL)
	{
		head = tail = new_item;
		cout << "\n>Element inserted in list\n";
	}
	else
	{
		tail->next = new_item;
		new_item->back = tail;
		tail = new_item;
		cout << "\n>Element inserted \n";
	}
}
void fixed_list() {
	string fixed_name_of_clothing, fixed_type_of_clothing, fixed_description, fixed_colour, fixed_item_id, fixed_quantity, fixed_size, fixed_price;
	string fixed_item[7][8] = { { "1", "Acne Studios", "Jeans", "Classic 5-pocket jeans with slim legs.", "6", "black" ,"32" ,"200" },
								{ "2", "Acne Studios", "T-shirts", "Classic crewneck t-shirt", "8", "white" ,"M" ,"90" },
								{ "3", "Farah Handford", "Shirt", "None", "1", "black" ,"M" ,"90" },
								{ "4", "FANMAIL", "Jeans", "Hemp and cotton-blend drill straight-leg trousers", "5", "black" ,"M" ,"250" },
								{ "5", "JOHN RICHMOND", "T-shirts", "refind print T-shirt", "3", "black" ,"M" ,"150" },
								{ "6", "JOHN RICHMOND ", "T-shirts", "raven print T-shirt", "2", "White" ,"XL" ,"210" },
								{ "7", "Piquadro Small", "Backpack", "Piquadro small computer backpack.", "1", "Brown" ,"none" ,"360" },
	};
	for (int i = 0; i < 7; i++) {
		Add_fixed_item(fixed_item[i][0], fixed_item[i][1], fixed_item[i][2], fixed_item[i][3], fixed_item[i][4], fixed_item[i][5], fixed_item[i][6], fixed_item[i][7]);
	}
}
void Add_fixed_item(string fixed_item_id, string fixed_name_of_clothing, string fixed_type_of_clothing,
	string fixed_description, string fixed_quantity, string fixed_colour, string fixed_size, string fixed_price)
{
	fixed_item = new Fixed_Clothes();
	fixed_item->fixed_item_id = std::stoi(fixed_item_id);
	fixed_item->fixed_name_of_clothing = fixed_name_of_clothing;
	fixed_item->fixed_type_of_clothing = fixed_type_of_clothing;
	fixed_item->fixed_description = fixed_description;
	fixed_item->fixed_quantity = std::stoi(fixed_quantity);
	fixed_item->fixed_colour = fixed_colour;
	fixed_item->fixed_size = (fixed_size);
	fixed_item->fixed_price = std::stof(fixed_price);
	fixed_item->back_f = NULL;
	fixed_item->next_f = NULL;
	if (head_f == NULL)
	{
		head_f = tail_f = fixed_item;
	}
	else
	{
		tail_f->next_f = fixed_item;
		fixed_item->back_f = tail_f;
		tail_f = fixed_item;
	}
}
void List_of_items()
{
	int a = 1;
	list_f = head_f;
	while (list_f != NULL)
	{

		cout << "Num.- " << a << ". ID: " << list_f->fixed_item_id << "\n\t-|-Item -" << list_f->fixed_name_of_clothing << "\n\t-|-Type - " << list_f->fixed_type_of_clothing << "\n\t-|-Description - " << list_f->fixed_description << "\n\t-|-Quantity - " << list_f->fixed_quantity << "\n\t-|-Color - " << list_f->fixed_colour << "\n\t-|-Size - " << list_f->fixed_size << "\n\t-|-Price in euro- " << list_f->fixed_price << ".\n";
		list_f = list_f->next_f;
		a++;
	}
}
void dispaly_added() {
	int i = 8;
	list = head;
	cout << "\t\n>>>>>-------New clothing------->>>>\n";
	while (list != NULL)
	{
		cout << "Num.- " << i << ". ID: " << list->item_id << "\n\t-|-Item -" << list->name_of_clothing << "\n\t-|-Type - " << list->type_of_clothing << "\n\t-|-Description - " << list->description << "\n\t-|-Quantity - " << list->quantity << "\n\t-|-Color - " << list->colour << "\n\t-|-Size - " << list->size << "\n\t-|-Price in euro - " << list->price << ".\n";
		list = list->next;
		i++;
	}
}
void search_in_fixed(string input)
{
	int i = 1; bool print = false;
	list_f = head_f;
	while (list_f != NULL)
	{
		if (list_f->fixed_type_of_clothing == input)
		{
			cout << "Num.: " << list_f->fixed_item_id << "\n\t-|-Item -" << list_f->fixed_name_of_clothing << "\n\t-|-Type - " << list_f->fixed_type_of_clothing << "\n\t-|-Description - " << list_f->fixed_description << "\n\t-|-Quantity - " << list_f->fixed_quantity << "\n\t-|-Color - " << list_f->fixed_colour << "\n\t-|-Size - " << list_f->fixed_size << "\n\t-|-Price in euro - " << list_f->fixed_price << ".\n";
			print = true;
		}
		list_f = list_f->next_f;
	}
	cout << endl;
	if (print == false)
	{
		cout << "\nAt the moment we do not have this type of clothing\n" << input << endl << endl;
	}
}
void search_in_added(string iput) {
	list = head; int i = 1; bool print = false;
	cout << "\n\t---------New clothes---------\n";
	while (list != NULL)
	{
		if (!(list->type_of_clothing.find(iput)))
		{
			cout << "ID: " << list->item_id << "\n\t-|-Item -" << list->name_of_clothing << "\n\t-|-Type - " << list->type_of_clothing << "\n\t-|-Description - " << list->description << "\n\t-|-Quantity - " << list->quantity << "\n\t-|-Color - " << list->colour << "\n\t-|-Size - " << list->size << "\n\t-|-Price in euro - " << list->price << ".\n";
			print = true;
		}
		list = list->next;
	}
	if (print == false)
	{
		cout << "\nAt the moment we do not have new clothing of this type\n" << iput << endl << endl;
	}
}
void move_by_clothes() {
	list_f = head_f; int i = 1, input;
	while (list_f != NULL)
	{
		cout << "Num.: " << list_f->fixed_item_id << "\n\t-|-Item -" << list_f->fixed_name_of_clothing << "\n\t-|-Type - " << list_f->fixed_type_of_clothing << "\n\t-|-Description - " << list_f->fixed_description << "\n\t-|-Quantity - " << list_f->fixed_quantity << "\n\t-|-Color - " << list_f->fixed_colour << "\n\t-|-Size - " << list_f->fixed_size << "\n\t-|-Price in euro - " << list_f->fixed_price << ".\n";
		cout << endl;
		if (i == 1)
		{
			cout << ">>Next item?\n[1] Yes [2] Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list_f = list_f->next_f;
				i++;
			}else{
				return;
			}
		}
		else
		{
			cout << ">>Select\n[1] To Next [2] To Previous [3]Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list_f = list_f->next_f;
				i++;
			}
			else if (input == 2)
			{
				list_f = list_f->back_f;
				i--;
			}
			else if (input == 3)
			{
				main();
			}
			else
			{
				return;
			}
		}
	}
}
void move_by_newclothes() {
	list = head; int i = 1, input;
	while (list != NULL)
	{
		cout << "Num.:" << list->item_id << "\n\t-|-Item -" << list->name_of_clothing << "\n\t-|-Type - " << list->type_of_clothing << "\n\t-|-Description - " << list->description << "\n\t-|-Quantity - " << list->quantity << "\n\t-|-Color - " << list->colour << "\n\t-|-Size - " << list->size << "\n\t-|-Price in euro - " << list->price << ".\n";
		cout << endl;
		if (i == 1)
		{
			cout << ">>Next item?\n[1] Yes [2] Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list = list->next;
				i++;
			}else
			{
				break;
			}
		}else{
			cout << ">>Select\n[1] To Next [2] To Previous [3]Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list = list->next;
				i++;
			}
			else if (input == 2)
			{
				list = list->back;
				i--;
			}
			else if (input == 3)
			{
				main();
			}
			else
			{
				break;
			}
		}
	}
	main();
}
void select_to_order() {
	int i = 1, input;
	list_f = head_f; 
	float price = 0;
	int  id = 0, quantity = 0;
	string name_of_clothing, type_of_clothing, description, colour, size;
	while (list_f != NULL)
	{
		cout << "ID. - " << list_f->fixed_item_id << "\n\t-|-Item -" << list_f->fixed_name_of_clothing << "\n\t-|-Type - " << list_f->fixed_type_of_clothing << "\n\t-|-Description - " << list_f->fixed_description << "\n\t-|-Quantity - " << list_f->fixed_quantity << "\n\t-|-Color - " << list_f->fixed_colour << "\n\t-|-Size - " << list_f->fixed_size << "\n\t-|-Price in euro - " << list_f->fixed_price << ".\n";
		id = list_f->fixed_item_id;
		name_of_clothing = list_f->fixed_name_of_clothing;
		type_of_clothing = list_f->fixed_type_of_clothing;
		description = list_f->fixed_description;
		quantity = list_f->fixed_quantity;
		colour = list_f->fixed_colour;
		size = list_f->fixed_size;
		price = list_f->fixed_price;
		cout << endl;
		if (i == 1)
		{
			cout << ">>Next item?[1] Yes [2] Add item to chekout [3] Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list_f = list_f->next_f;
				i++;
			}else if (input == 2){
				Add_to_selected(id, quantity, price, name_of_clothing, type_of_clothing, description, colour, size);
				cout << "\n\n>>>Item was added to checkout<<<<\n\n";
				system("PAUSE");
				list_f = list_f->next_f;
				i++;
			}
			else {
				return;
			}
		}
		else
		{
			cout << ">>Select\n[1] To Next [2] To Previous [3] Add to checkout [4]Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list_f = list_f->next_f;
				i++;
			}
			else if (input == 2)
			{
				list_f = list_f->back_f;
				i--;
			}
			else if (input == 3)
			{
				Add_to_selected(id, quantity, price, name_of_clothing, type_of_clothing, description, colour, size);
				cout << "\n\n>>>Item was added to checkout<<<<\n\n";
				system("PAUSE");
				list_f = list_f->next_f;
				i++;
			}
			else if (input == 4)
			{
				main();
			}
			else
			{
				return;
			}
		}
	}
}
void select_to_order_non_fixed() {
	list = head; int i = 1, input;
	float price_n = 0; int  id_n = 0, quantity_n = 0;
	string name_of_clothing_n, type_of_clothing_n, description_n, colour_n, size_n;
	while (list != NULL)
	{
		cout << "ID.: " << list->item_id << "\n\t-|-Item -" << list->name_of_clothing << "\n\t-|-Type - " << list->type_of_clothing << "\n\t-|-Description - " << list->description << "\n\t-|-Quantity - " << list->quantity << "\n\t-|-Color - " << list->colour << "\n\t-|-Size - " << list->size << "\n\t-|-Price in euro - " << list->price << ".\n";
		id_n = list->item_id;
		name_of_clothing_n = list->name_of_clothing;
		type_of_clothing_n = list->type_of_clothing;
		description_n = list->description;
		quantity_n = list->quantity;
		colour_n = list->colour;
		size_n = list->size;
		price_n = list->price;
		cout << endl;
		if (i == 1)
		{
			cout << ">>Next item?[1] Yes [2]Add to checkout [3] Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list = list->next;
				i++;
			}
			else if (input == 2)
			{
				Add_to_selected(id_n, quantity_n , price_n, name_of_clothing_n, type_of_clothing_n, description_n, colour_n, size_n);
				cout << "\n\n>>>Item was added to checkout<<<<\n\n";
				system("PAUSE");
				list = list->next;
				i++;
			}
			else
			{
				break;
			}
		}
		else {
			cout << ">>Select\n[1] To Next [2] To Previous [3] Add to checkout [4]Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list = list->next;
				i++;
			}
			else if (input == 2)
			{
				list = list->back;
				i--;
			}
			else if (input == 3)
			{
				Add_to_selected(id_n, quantity_n, price_n, name_of_clothing_n, type_of_clothing_n, description_n, colour_n, size_n);
				cout << "\n\n>>>Item was added to checkout<<<<\n\n";
				system("PAUSE");
				list = list->next;
				i++;
			}
			else if (input == 4)
			{
				main();
			}
			else
			{
				break;
			}
		}
	}
	main();
}
void view_orders() {
	list_check = head_check;
	int a = 1;
	while (list_check != NULL)
	{
		cout << "Num " << a << ". ID: " << list_check->checkout_item_id << "\n\t-|-Item -" << list_check->checkout_name_of_clothing << "\n\t-|-Color - " << list_check->checkout_colour << "\n\t-|-Size - " << list_check->checkout_size << "\n\t-|-Price in euro- " << list_check->checkout_price << "\n\t-|-Name- " << list_check->buyername << "\n\t-|-Address- " << list_check->address << "\n\t-|-Phone number- " << list_check->phone_nember << ".\n";
		list_check = list_check->next_check;
		a++;
	}
	system("PAUSE");
	main();
}
void Add_to_selected(int id,int quantity, float price, string name_of_clothing,string type_of_clothing, string description, string colour,string size) {
	selected_item = new Selected_Clothes();
	selected_item->selected_item_id = id;
	selected_item->selected_name_of_clothing = name_of_clothing;
	selected_item->selected_type_of_clothing = type_of_clothing;
	selected_item->selected_description = description;
	selected_item->selected_quantity = quantity;
	selected_item->selected_colour = colour;
	selected_item->selected_size = size;
	selected_item->selected_price = price;
	selected_item->back_seld = NULL;
	selected_item->next_seld = NULL;
	if (head_seld == NULL)
	{
		head_seld = tail_seld = selected_item;
	}
	else
	{
		tail_seld->next_seld = selected_item;
		selected_item->back_seld = tail_seld;
		tail_seld = selected_item;
	}
	new_price = price;
	old_price = old_price + new_price;
	total = old_price;
}
void checkout() {
	int a = 1,input;
	list_seld = head_seld;
	while (list_seld != NULL)
	{
		cout << "Num " << a << ". ID: " << list_seld->selected_item_id << "\n\t-|-Item -" << list_seld->selected_name_of_clothing << "\n\t-|-Type - " << list_seld->selected_type_of_clothing << "\n\t-|-Description - " << list_seld->selected_description << "\n\t-|-Quantity - " << list_seld->selected_quantity << "\n\t-|-Color - " << list_seld->selected_colour << "\n\t-|-Size - " << list_seld->selected_size << "\n\t-|-Price in euro- " << list_seld->selected_price << ".\n";
		list_seld = list_seld->next_seld;
		a++;
	}
	cout << ">>>Total amount to pay(euro)\t: "<<total<<"\n";
	cout << ">>>Do you whant to checkyour? [1] Yes , [2] No\nSelect: ";
	cin >> input;
	switch (input)
	{
	case 1:
		checkout_step2();
		break;
	case 2:main(); break;
	default:break;
	}
	system("PAUSE");
	main();
}
void checkout_step2() {
	int i = 1, input;
	list_seld = head_seld;
	float price = 0;
	int  id = 0, quantity = 0, a=1, remValue=0;
	string name_of_clothing, type_of_clothing, description, colour, size;
	while (list_seld != NULL)
	{
		cout << "Num " << a <<". ID: "<<list_seld->selected_item_id <<"\n\t-|-Item -" << list_seld->selected_name_of_clothing << "\n\t-|-Type - " << list_seld->selected_type_of_clothing << "\n\t-|-Description - " << list_seld->selected_description << "\n\t-|-Quantity - " << list_seld->selected_quantity << "\n\t-|-Color - " << list_seld->selected_colour << "\n\t-|-Size - " << list_seld->selected_size << "\n\t-|-Price in euro- " << list_seld->selected_price << ".\n";
		a++;
		name_of_clothing = list_seld->selected_name_of_clothing;
		colour = list_seld->selected_colour;
		size = list_seld->selected_size;
		price = list_seld->selected_price;
		remValue = list_seld->selected_item_id;
		cout << endl;
		if (i == 1)
		{
			cout << ">>Next item?[1] Yes [2]Make Order [3] Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list_f = list_f->next_f;
				i++;
			}
			else if (input == 2) {
				string buyer_name, address;
				int phone_number;
				cout << "Enter Name\t: ";
				cin >> buyer_name;
				cout << "Enter Address\t: ";
				cin >> address;
				cout << "Enter Phone num\t: ";
				cin >> phone_number;
				cout << "Price of the product in euro\t: " << price << "\n";
				cout << "Do you whant delivery?(Additional 50 euros)\nSelect [1] Yes [2] No\n";
				if (input == 1) {
					price = price + 50;
					Add_to_orders(remValue, price, name_of_clothing, colour, size, buyer_name, address, phone_number);
				}
				else {
					Add_to_orders(remValue, price, name_of_clothing, colour, size, buyer_name, address, phone_number);
				};
				cout << "\n\n>>>The item was successfully paid, wait<<<<\n\n";
				system("PAUSE");
				list_f = list_f->next_f;
				i++;
			}
			else {
				return;
			}
		}
		else
		{
			cout << ">>[1] To Next [2] To Previous [3] Make Order [4]Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list_f = list_f->next_f;
				i++;
			}
			else if (input == 2)
			{
				list_f = list_f->back_f;
				i--;
			}
			else if (input == 3)
			{
				string buyer_name, address;
				int phone_number;
				cout << "Enter Name\t: ";
				cin >> buyer_name;
				cout << "Enter Address\t: ";
				cin >> address;
				cout << "Enter Phone num\t: ";
				cin >> phone_number;
				cout << "Price of the product in euro\t: " << price << "\n";
				cout << "Do you whant delivery?(Additional 50 euros)\nSelect [1] Yes [2] No\n";
				if (input == 1) {
					price = price + 50;
					Add_to_orders(remValue, price, name_of_clothing, colour, size, buyer_name, address, phone_number);
				}
				else {
					Add_to_orders(remValue, price, name_of_clothing, colour, size, buyer_name, address, phone_number);
				}
				cout << "\n\n>>>The item was successfully paid, wait<<<<\n\n";
				system("PAUSE");
				list_f = list_f->next_f;
				i++;
			}
			else if (input == 4)
			{
				main();
			}
			else
			{
				return;
			}
		}
	}
}
void Add_to_orders(int remValue, float price, string name_of_clothing, string colour, string size, string buyer_name,string address,int phone_number){
	int id = 0;
		list_check = head_check;
		while (list_check != NULL)
		{
			id = list_check->checkout_item_id;
			list_check = list_check->next_check;

		}
		if (id >= 0) {
			id++;
		}
		total = total - price;
		selected_check = new Checkout();
		selected_check->checkout_item_id = id;
		selected_check->checkout_name_of_clothing = name_of_clothing;
		selected_check->checkout_colour = colour;
		selected_check->checkout_size = size;
		selected_check->checkout_price = price;
		selected_check->buyername = buyer_name;
		selected_check->address = address;
		selected_check->phone_nember = phone_number;
		selected_check->back_check = NULL;
		selected_check->next_check = NULL;
		if (head_check == NULL)
		{
			head_check = tail_check = selected_check;
		}
		else
		{

			tail_check->next_check = selected_check;
			selected_check->back_check = tail_check;
			tail_check = selected_check;
		}
}
void delete_node_from_selected(int remValue) {

	list_check = head_check;
	while (list_check->checkout_item_id != remValue) {
		previous_check = list_check;
		list_check = list_check->next_check;
		if (list_check == NULL)
		{
			break;
		}
	}
	if (list_check != NULL && list_check->checkout_item_id == remValue)
	{
		if (list_check == tail_check) //last node to be deleted
		{
			deleteAtEnd();
		}
		else if (list_check == head_check) { //first node to be deleted
			deleteAtBeginning();
		}
		else {
			
			previous_check->next_check = previous_check->next_check->next_check;
			list_check->next_check->back_check = previous_check;
			delete list_check;
		}
		delete_node_from_selected(remValue);
	}
	else
	{
		return;
	}
}
void deleteAtBeginning() {
	list_check = head_check;
	head_check->next_check->back_check = NULL;
	head_check = head_check->next_check;
	delete list_check; 
}
void deleteAtEnd() {
	list_seld = tail_seld;
	tail_seld->back_seld->next_seld = NULL;
	tail_seld = tail_seld->back_seld;
	delete list_seld; 
}
void deleteAllSongs()
{
	list_check = head_check;
	while (list_check != NULL)
	{
		head_check = head_check->next_check;
		delete list_seld;
		list_check = head_check;
	}
}
void move_between_orders() {
	list_check = head_check; int i = 1, input;
	int a = 1;
	while (list_seld != NULL)
	{
		cout << "Num " << a << ". ID: " << list_check->checkout_item_id << "\n\t-|-Item -" << list_check->checkout_name_of_clothing << "\n\t-|-Color - " << list_check->checkout_colour << "\n\t-|-Size - " << list_check->checkout_size << "\n\t-|-Price in euro- " << list_check->checkout_price << "\n\t-|-Name- " << list_check->buyername << "\n\t-|-Address- " << list_check->address << "\n\t-|-Phone number- " << list_check->phone_nember << ".\n";
		list_check = list_check->next_check;
		a++;
		if (i == 1)
		{
			cout << ">>Next item?\n[1] Yes [2] Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list_check = list_check->next_check;
				i++;
			}
			else
			{
				return;
			}
		}
		else {
			cout << ">>Select\n[1] To Next [2] To Previous [3]Go back to Menu\nSelect: ";
			cin >> input;
			cin.ignore();
			cout << endl;
			if (input == 1)
			{
				list_check = list_check->next_check;
				i++;
			}
			else if (input == 2)
			{
				list_check = list_check->next_check;
				i--;
			}
			else if (input == 3)
			{
				main();
			}
			else
			{
				return;
			}
		}
	}
}